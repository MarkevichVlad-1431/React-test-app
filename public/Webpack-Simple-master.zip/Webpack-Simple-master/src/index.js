import 'normalize.css'
import './styles/main.scss';